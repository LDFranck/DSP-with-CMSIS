/******************************* SOURCE LICENSE *********************************
Copyright (c) 2018 MicroModeler.

A non-exclusive, nontransferable, perpetual, royalty-free license is granted to the Licensee to
use the following Information for academic, non-profit, or government-sponsored research purposes.
Use of the following Information under this License is restricted to NON-COMMERCIAL PURPOSES ONLY.
Commercial use of the following Information requires a separately executed written license agreement.

This Information is distributed WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

******************************* END OF LICENSE *********************************/

// A commercial license for MicroModeler DSP can be obtained at http://www.micromodeler.com/launch.jsp

#include "filter.h"

#include <stdlib.h> // For malloc/free
#include <string.h> // For memset

float32_t filter_coefficients[10] =
{
// Scaled for floating point

    0.041590868196395084, 0.08318173639279017, 0.041590868196395084, 1.4515445912570875, -0.5699650474507367,// b0, b1, b2, a1, a2
    0.0625, 0.125, 0.0625, 1.4388582453987726, -0.808555992457365// b0, b1, b2, a1, a2

};


filterType *filter_create( void )
{
	filterType *result = (filterType *)malloc( sizeof( filterType ) );	// Allocate memory for the object
	filter_init( result );											// Initialize it
	return result;																// Return the result
}

void filter_destroy( filterType *pObject )
{
	free( pObject );
}

 void filter_init( filterType * pThis )
{
	arm_biquad_cascade_df1_init_f32(	&pThis->instance, filter_numStages, filter_coefficients, pThis->state );
	filter_reset( pThis );

}

 void filter_reset( filterType * pThis )
{
	memset( &pThis->state, 0, sizeof( pThis->state ) ); // Reset state to 0
	pThis->output = 0;									// Reset output

}

 int filter_filterBlock( filterType * pThis, float * pInput, float * pOutput, unsigned int count )
{
	arm_biquad_cascade_df1_f32( &pThis->instance, pInput, pOutput, count );
	return count;

}


