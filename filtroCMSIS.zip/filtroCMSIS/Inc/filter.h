/******************************* SOURCE LICENSE *********************************
Copyright (c) 2018 MicroModeler.

A non-exclusive, nontransferable, perpetual, royalty-free license is granted to the Licensee to
use the following Information for academic, non-profit, or government-sponsored research purposes.
Use of the following Information under this License is restricted to NON-COMMERCIAL PURPOSES ONLY.
Commercial use of the following Information requires a separately executed written license agreement.

This Information is distributed WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

******************************* END OF LICENSE *********************************/

// A commercial license for MicroModeler DSP can be obtained at http://www.micromodeler.com/launch.jsp

// Begin header file, filter.h

#ifndef FILTER_H_ // Include guards
#define FILTER_H_

#define ARM_MATH_CM4	// Use ARM Cortex M4
#define __FPU_PRESENT 1		// Does this device have a floating point unit?
#include <arm_math.h>	// Include CMSIS header

// Link with library: libarm_cortexM4_mathL.a (or equivalent)
// Add CMSIS/Lib/GCC to the library search path
// Add CMSIS/Include to the include search path
extern float32_t filter_coefficients[10];
static const int filter_numStages = 2;

typedef struct
{
	arm_biquad_casd_df1_inst_f32 instance;
	float32_t state[8];
	float32_t output;
} filterType;


filterType *filter_create( void );
void filter_destroy( filterType *pObject );
 void filter_init( filterType * pThis );
 void filter_reset( filterType * pThis );
#define filter_writeInput( pThis, input )  \
	arm_biquad_cascade_df1_f32( &pThis->instance, &input, &pThis->output, 1 );

#define filter_readOutput( pThis )  \
	pThis->output


 int filter_filterBlock( filterType * pThis, float * pInput, float * pOutput, unsigned int count );
#define filter_outputToFloat( output )  \
	(output)

#define filter_inputFromFloat( input )  \
	(input)

#endif // FILTER_H_

